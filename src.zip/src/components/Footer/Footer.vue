<template>
    <div class="footer" style="color: white;">
        footer
    </div>
</template>

<script setup>

</script>

