<template>
    <div class="main">
        <Upcoming />
        <Movies />
        <Tvs />
    </div>
</template>

<script setup>

import Upcoming from '@/components/Upcoming/Upcoming.vue'
import Movies from "@/components/MOT/Movies.vue";
import Tvs from "@/components/MOT/Tvs.vue";

</script>
