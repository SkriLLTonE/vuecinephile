<template>
    <div class="footer" style="color: white; background: white;">

    </div>
</template>

<script setup>

</script>

<style lang="scss" scoped>

</style>