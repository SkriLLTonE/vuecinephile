<template>
    <Content type="movie" />
</template>

<script setup>
    import Content from "./Content.vue";
</script>
 