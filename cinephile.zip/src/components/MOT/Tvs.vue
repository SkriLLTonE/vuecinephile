<template>
    <Content type="tv" />
</template>

<script setup>
    import Content from "./Content.vue";
</script>
