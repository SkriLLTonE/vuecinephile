export const apiKey = 'c996566c65c192b00dcc2aa022528e6a'

export const imgUrlFull = 'https://image.tmdb.org/t/p/original'

export const imgUrl = 'https://image.tmdb.org/t/p/w500'